package anew.projetokatsu.com.fragments;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import anew.projetokatsu.com.projetokatsunew.R;

public class ConteudoAnime2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.conteudo_anime2);
    }
}
